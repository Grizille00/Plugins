<?php

// $test = array(
//     'hello',
//     'hwu'
// );

// $reel ="hello";


// if (str_contains('hello',$reel) || 1==2){
//     echo "hi";
// }
$me =33;
$res = str_po($me,string);
echo $res;