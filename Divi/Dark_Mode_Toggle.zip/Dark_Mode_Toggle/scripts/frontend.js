// This script is loaded both on the frontend page and in the Visual Builder.
const get = (item,mode=0)=>{
    if (mode===0){
      return document.querySelector(item)
    } else{
      return document.querySelectorAll(item)
    }
  }


const add = (tag,text)=>{
    const el = document.createElement(tag)
    el.textContent = text
    return el
}

const push_styles = ()=>{
    const fg = get('.fg').textContent
    const bg = get('.bg').textContent
    const el = document.createElement('style')
    const styles = `
        .dark{
            background:${bg} !important;
        }
        .frag{
            color:${fg} !important;
        }
    `
    el.textContent = styles
    get('body').appendChild(el)
}


const targets = []
const exceptions = []
push_styles()


let items = get('.sub0').textContent.trim().split('\n')
for (let x = 0; x < items.length; x++) {
    if(items[x].length>0){
        const x_items = get(items[x],1)
        console.log(x_items)
        for (let y = 0; y < x_items.length; y++) {
            targets.push(x_items[y])        
        }
    }
}

items = get('.sub1').textContent.split('\n')
for (let x = 0; x < items.length; x++) {
    exceptions.push(items[x])        
}

const chk = {
    light:1,
    dark:0
}


const toggler = get('#toggle_icons')
if(toggler){
    // set light as default
    toggler.addEventListener('click',()=>{
        toggle()
        if (chk.light == 1){
            get('#light-ico').classList.toggle('active',true)
            get('#dark-ico').classList.toggle('active',false)
            chk.light =0
            chk.dark = 1
        } else{
            get('#light-ico').classList.toggle('active',false)
            get('#dark-ico').classList.toggle('active',true)            
            chk.dark = 0
            chk.light =1
            
        }
    })

}


const rundown = (state)=>{
    const el = state
    if(el){
        for (let i = 0; i < el.length; i++) {
            let pass = false
            for (let xx = 0; xx < exceptions.length; xx++) {
                if (el[i].classList.contains(exceptions[xx])){
                    pass = true
                } 
            }
            if(pass){
                continue
            }
            else{
                const col = el[i].children
                    if (col.length >0){
                        // el[i].style.background = 'transparent !important'
                        rundown(col)
                    } else{
                        // console.log(el[i],exceptions,'\n\n')
                        el[i].classList.toggle('frag')
                        
                }

            }
            
            }

    }

}

const activate = ()=>{
    for (let item = 0; item < targets.length; item++) {
        console.log(targets)
        targets[item].classList.toggle('dark')
        const children = targets[item].children
        rundown(children)
    }
}


const toggle = ()=>{
    activate()
}

