// import HelloWorld from './HelloWorld/HelloWorld';

import DarkMode from "./DarkMode/DarkMode";

export default [DarkMode];
