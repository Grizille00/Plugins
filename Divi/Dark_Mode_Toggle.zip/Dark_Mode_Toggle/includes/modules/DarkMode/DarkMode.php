<?php

class NEW_DarkMode extends ET_Builder_Module {

	public $slug       = 'new_dark_mode';
	public $vb_support = 'on';

	protected $module_credits = array(
		'module_uri' => 'https://bit.ly/fern-helper',
		'author'     => 'Michael Sithole',
		'author_uri' => 'michael.sithole@uncommon.org',
	);

	public function init() {
		$this->name = esc_html__( 'Dark/Light Toggle', 'new-new' );
		$this->icon_path =  plugin_dir_path( __FILE__ ) . 'icon.svg';

		$this->settings_modal_toggles  = array(
			'general'  => array(
				'toggles' => array(
					'main_content' => esc_html__( 'Toggle Sections', 'new-new' ),
					'color_picks'        => esc_html__( 'Toggle Colors', 'new-new' ),
					'icons'        => esc_html__( 'Toggle Icons', 'new-new' ),
				),
			),
		);
	}

	

	public function get_fields() {
		return array(
			'sections' => array(
				'label'           => esc_html__( 'Sections for Light/Dark Toggle Selectors', 'new-new' ),
				'type'            => 'textarea',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'sections with the css Selectors entered here will be controlled by the light/dark toggle.', 'new-new' ),
				'toggle_slug'     => 'main_content',
			),
			'exceptions' => array(
				'label'           => esc_html__( 'Sections Not Affected Class Names', 'new-new' ),
				'type'            => 'textarea',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'sections with the classnames entered here will be excluded from the light/dark toggle.', 'new-new' ),
				'toggle_slug'     => 'main_content',
			),
			'color' => array(
				'label'          => esc_html__( 'Dark Mode Text Color', 'new-new' ),
				'description'    => esc_html__( 'The Color Selected here will be used .', 'new-new' ),
				'type'           => 'color-alpha',
				'custom_color'   => true,
				'option_category' => 'basic_option',
				'toggle_slug'    => 'color_picks',
			),
			'background' => array(
				'label'          => esc_html__( 'Dark Mode Background Color', 'new-new' ),
				'description'    => esc_html__( 'The Background Color Selected here will be used .', 'new-new' ),
				'type'           => 'color-alpha',
				'custom_color'   => true,
				'option_category' => 'basic_option',
				'toggle_slug'    => 'color_picks',
			),
			'dark_icon' => array(
				'label'              => esc_html__( 'Dark Toggle Icon', 'new-new' ),
				'type'               => 'upload',
				'option_category'    => 'basic_option',
				'upload_button_text' => esc_attr__( 'Select Dark Toggle Icon', 'new-new' ),
				'choose_text'        => esc_attr__( 'Choose Dark Toggle Icon', 'new-new' ),
				'update_text'        => esc_attr__( 'Set Dark Toggle Icon', 'new-new' ),
				'description'        => esc_html__( 'This will be the icon used to switch to dark mode.', 'new-new_builder' ),
				'toggle_slug'        => 'icons',
			),

			'light_icon' => array(
				'label'              => esc_html__( 'Light Toggle Icon', 'new-new' ),
				'type'               => 'upload',
				'option_category'    => 'basic_option',
				'upload_button_text' => esc_attr__( 'Select Light Toggle Icon', 'new-new' ),
				'choose_text'        => esc_attr__( 'Choose Light Toggle Icon', 'new-new' ),
				'update_text'        => esc_attr__( 'Set Light Toggle Icon', 'new-new' ),
				'description'        => esc_html__( 'This will be the icon used to switch to light mode.', 'new-new_builder' ),
				'toggle_slug'        => 'icons',
			),
		);
	}

	public function render( $attrs, $content = null, $render_slug ) {
	
		return sprintf( '
		<div class="dark-wrapper">
			<p class="sub0">%1$s</p>
			<p class="sub1">%2$s</p>
			<p class="fg">%3$s</p>
			<p class="bg">%4$s</p>
			<p id="toggle_icons">
				<img id="light-ico" class="et_pb_image" src=%5$s />
				<img id="dark-ico" class="et_pb_image active" src=%6$s />
         	 </p>
		</div>
		',
		 $this->props['sections'],
		 $this->props['exceptions'],
		 $this->props['color'],
		 $this->props['background'],
		 $this->props['light_icon'],
		 $this->props['dark_icon'],
	);
	}
}

new NEW_DarkMode;
