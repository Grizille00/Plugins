// External Dependencies
import React, { Component } from 'react';

// Internal Dependencies
import './style.css';


class DarkMode extends Component {

  static slug = 'new_dark_mode';

  render() {
    // const Content = this.props.sections;

    return (
      <div className='dark-wrapper'>
          <p className='sub0'>{this.props.sections}</p>
          <p className='sub1'>{this.props.exceptions}</p>
          <p className='fg'>{this.props.color}</p>
          <p className='bg'>{this.props.background}</p>
          <p id='toggle_icons'>
            <img id="light-ico" className='et_pb_image' src={this.props.light_icon} alt=""/>
            <img id="dark-ico" className='et_pb_image active' src={this.props.dark_icon} alt=""/>
          </p>
      </div>
    );
  }
}

export default DarkMode;
