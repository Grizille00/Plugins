// This script is loaded both on the frontend page and in the Visual Builder.
const get = (item,mode=0)=>{
    if (mode===0){
      return document.querySelector(item)
    } else{
      return document.querySelectorAll(item)
    }
  }



const accord_items = get('.accordion-wrapper')


const close_all = ()=>{
    const items = get('.accordion-item .accordion-body',1)
    const open_modals = get('.accordion-item .open-icon',1)
    const close_modals = get('.accordion-item .close-icon',1)

    for (let x = 0; x < items.length; x++) {
        items[x].classList.remove('active')
        
    }

    for (let x = 0; x < open_modals.length; x++) {
        open_modals[x].classList.add('active')
    }


    for (let x = 0; x < close_modals.length; x++) {
        close_modals[x].classList.remove('active')   
    }
}

const switch_item= (new_item)=>{
    close_all()
    new_item.getElementsByClassName('accordion-body')[0].classList.add('active')
    new_item.getElementsByClassName('open-icon')[0].classList.toggle('active')
    new_item.getElementsByClassName('close-icon')[0].classList.toggle('active')
}


for (let i = 0; i < accord_items.children.length; i++) {
    const item = accord_items.children[i]
    const control = item.getElementsByClassName('.accordion-controls')[0]
    control.addEventListener('click',()=>{
        switch_item(item)
    })
}

switch_item(accord_items.children[0])




