<?php

class NEW_AccordionChild extends ET_Builder_Module {

	public $slug       = 'new_fern_accordion_child';
    public $type        = 'child';
    public $child_title_var   = 'category';
	public $vb_support = 'on';

	protected $module_credits = array(
		'module_uri' => 'https://bit.ly/fern-helper',
		'author'     => 'Michael Sithole',
		'author_uri' => 'michael.sithole@uncommon.org',
	);

	public function init() {
		$this->name = esc_html__( 'Accord Item', 'new-new' );
        $this->plural = esc_html__( 'Accord Items', 'new-new' );


        $this->main_css_element = '%%order_class%% .accordion-item';


		$this->settings_text = esc_html__( 'Accord Item', 'new-new' );

        $this->settings_modal_toggles  = array(
			'general'  => array(
				'toggles' => array(
					'settings_content'	=> esc_html__( 'Accord Item', 'new-new' ),
					'main_content'	=> esc_html__( 'Item Content', 'new-new' ),
					'footer'	=> esc_html__( 'Item Footer', 'new-new' ),	
                    'icons'	=> esc_html__( 'Control Icons', 'new-new' ),	
				),
			),


			'advanced'	=>	array(
				'toggles'	=>	array(
					'image' =>  esc_html__( 'Toggle Settings', 'new-new'),
					'sizes' =>  esc_html__( 'Content Spacing', 'new-new'),
					'footer_settings' =>  esc_html__( 'Footer Settings', 'new-new'),
				),
			),

        );
        

	}

	function get_advanced_fields_config(){
		return array(
			'fonts'		=>	array(
				'category'	=>	array(
					'label'	=>	esc_html__( 'Item Category', 'new-new' ),
					'css'	=> array(
						'main'	=>	"{$this->main_css_element} .accordion-title",
						'font'	=>	"{$this->main_css_element} .accordion-title",
						'color' => "{$this->main_css_element} .accordion-title",
						'plugin_main' => "{$this->main_css_element} .accordion-title, {$this->main_css_element} .accordion-title",
						'text_align' => "{$this->main_css_element} .accordion-title",
						'important' => 'all',
					),
					'use_alignment' => true,
					'header_level' => array(
						'default' => 'h2',
					),
					'hide_text_shadow' => true,
					),
				'title'	=>	array(
					'label'	=>	esc_html__( 'Item Title', 'new-new' ),
					'css'	=> array(
						'main'	=>	"{$this->main_css_element} .accordion-body .body-title",
						'font'	=>	"{$this->main_css_element} .accordion-body .body-title",
						'color' => "{$this->main_css_element} .accordion-body .body-title",
						'plugin_main' => "{$this->main_css_element} .accordion-body .body-title, {$this->main_css_element} .accordion-body .body-title",
						'text_align' => "{$this->main_css_element} .accordion-body .body-title",
						'important' => 'all',
					),
					'use_alignment' => true,
					'header_level' => array(
						'default' => 'h2',
					),
					'hide_text_shadow' => true,
				),
				'content'   => array(
					'label'    => esc_html__( 'Content', 'new-new' ),
					'css'      => array(
						'main'        => "{$this->main_css_element} .accordion-body .body-text",
						'color'       => "{$this->main_css_element}, {$this->main_css_element} .accordion-body .body-text *",
						'padding' 	=>	"{$this->main_css_element} .accordion-body .body-title",
						'line_height' => "{$this->main_css_element} .accordion-body .body-text",
						'plugin_main' => "{$this->main_css_element}, %%order_class%% .accordion-body .body-text",
					),
					'hide_text_shadow' => true,
				),
			),


			'margin_padding' => array(

				'title'	=>	array(
					'label'	=>	esc_html__( 'Item Title', 'new-new' ),
					'css'	=> array(
						'margin' => "{$this->main_css_element} .accordion-body .body-title",
						'padding' => "{$this->main_css_element} .accordion-body .body-title",
					),
				),
				// 'css' => array(
				// 	'important' => 'all',
				// ),
			),
		);
	}

    

    public function get_fields() {
        return array(
			'category' => array(
				'label'           => esc_html__( 'Item Category', 'new-new' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'This is the item category.', 'new-new' ),
				'toggle_slug'     => 'settings_content',
			),

            'title' => array(
				'label'           => esc_html__( 'Content Title', 'new-new' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'This is the title of your accordion item.', 'new-new' ),
				'toggle_slug'     => 'main_content',
			),
            'content' => array(
				'label'           => esc_html__( 'Content Text', 'new-new' ),
				'type'            => 'tiny_mce',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'Tab Item Content.', 'new-new' ),
				'toggle_slug'     => 'main_content',
			),
            'open_icon' => array(
				'label'              => esc_html__( 'Open Icon', 'new-new' ),
				'type'               => 'upload',
				'option_category'    => 'basic_option',
				'upload_button_text' => esc_attr__( 'Upload Open Icon', 'new-new' ),
				'choose_text'        => esc_attr__( 'Choose Open Icon', 'new-new' ),
				'update_text'        => esc_attr__( 'Set As Open Icon', 'new-new' ),
				'hide_metadata'      => true,
				'affects'            => array(
					'alt',
					'title_text',
				),
				'description'        => esc_html__( 'Upload your desired image, or type in the URL to the image you would like to display as open icon.', 'new-new' ),
				'toggle_slug'        => 'icons',
				'dynamic_content'    => 'icons',
			),
            'close_icon' => array(
				'label'              => esc_html__( 'Close Icon', 'new-new' ),
				'type'               => 'upload',
				'option_category'    => 'basic_option',
				'upload_button_text' => esc_attr__( 'Upload Close Icon', 'new-new' ),
				'choose_text'        => esc_attr__( 'Choose Close Icon', 'new-new' ),
				'update_text'        => esc_attr__( 'Set Close Icon', 'new-new' ),
				'hide_metadata'      => true,
				'affects'            => array(
					'alt',
					'title_text',
				),
				'description'        => esc_html__( 'Upload your desired image, or type in the URL to the image you would like to display as close icon.', 'new-new' ),
				'toggle_slug'        => 'icons',
				'dynamic_content'    => 'icons',
			),

			'image' => array(
				'label'             => esc_html__( 'Toggle Icon Size', 'new-new' ),
				'type'              => 'range',
				'range_settings' => array(
					'min'  => '1',
					'max'  => '100',
					'step' => '1',
				),
				'option_category'   => 'image',
				'default_on_front'  => 'off',
				'description'       => esc_html__( 'Toggle between the various blog layout types.', 'new-new' ),
				'tab_slug'    => 'advanced',
				'toggle_slug' => 'image',
			),


			'title_space' => array(
				'label'             => esc_html__( 'Content Title Space Size', 'new-new' ),
				'type'              => 'range',
				'range_settings' => array(
					'min'  => '1',
					'max'  => '100',
					'step' => '1',
				),
				'option_category'   => 'sizes',
				'default_on_front'  => 'off',
				'description'       => esc_html__( 'Toggle between the various blog layout types.', 'new-new' ),
				'tab_slug'    => 'advanced',
				'toggle_slug' => 'sizes',
			),


			'text_space' => array(
				'label'             => esc_html__( 'Content Text Space Size', 'new-new' ),
				'type'              => 'range',
				'range_settings' => array(
					'min'  => '1',
					'max'  => '100',
					'step' => '1',
				),
				'option_category'   => 'sizes',
				'default_on_front'  => 'off',
				'description'       => esc_html__( 'Toggle between the various blog layout types.', 'new-new' ),
				'tab_slug'    => 'advanced',
				'toggle_slug' => 'sizes',
			),



			'title_size' => array(
				'label'             => esc_html__( 'Content Title Height', 'new-new' ),
				'type'              => 'range',
				'range_settings' => array(
					'min'  => '1',
					'max'  => '100',
					'step' => '1',
				),
				'option_category'   => 'sizes',
				'default_on_front'  => 'off',
				'description'       => esc_html__( 'Toggle between the various blog layout types.', 'new-new' ),
				'tab_slug'    => 'advanced',
				'toggle_slug' => 'sizes',
			),


			'text_size' => array(
				'label'             => esc_html__( 'Content Text Height', 'new-new' ),
				'type'              => 'range',
				'range_settings' => array(
					'min'  => '1',
					'max'  => '100',
					'step' => '1',
				),
				'option_category'   => 'sizes',
				'default_on_front'  => 'off',
				'description'       => esc_html__( 'Toggle between the various blog layout types.', 'new-new' ),
				'tab_slug'    => 'advanced',
				'toggle_slug' => 'sizes',
			),


			'footer_text' => array(
				'label'           => esc_html__( 'Footer Text', 'new-new' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'This is the item category.', 'new-new' ),
				'toggle_slug'     => 'footer',
			),



			'footer_icon' => array(
				'label'              => esc_html__( 'Footer Icon', 'new-new' ),
				'type'               => 'upload',
				'option_category'    => 'basic_option',
				'upload_button_text' => esc_attr__( 'Upload Open Icon', 'new-new' ),
				'choose_text'        => esc_attr__( 'Choose Open Icon', 'new-new' ),
				'update_text'        => esc_attr__( 'Set As Open Icon', 'new-new' ),
				'hide_metadata'      => true,
				'affects'            => array(
					'alt',
					'title_text',
				),
				'description'        => esc_html__( 'Upload your desired image, or type in the URL to the image you would like to display as open icon.', 'new-new' ),
				'toggle_slug'        => 'footer',
				'dynamic_content'    => 'footer',
			),


			'footer_bg' => array(
				'label'             => esc_html__( 'Footer Background', 'new-new' ),
				'type'              => 'color-alpha',
				'option_category'   => 'footer_settings',
				'default_on_front'  => 'off',
				'description'       => esc_html__( 'Toggle between the various blog layout types.', 'new-new' ),
				'tab_slug'    => 'advanced',
				'toggle_slug' => 'footer_settings',
			),


        );
    }


	public function get_transition_fields_css_props(){
		$fields = parent::get_transition_fields_css_props();
		$fields['image'] = array(
			'width'	=> '%%order_class%% .tog-item'
		);

		$fields['footer_bg'] = array(
			'background'	=> '%%order_class%% .accordion-item .item-footer'
		);
		return $fields;
	}



	public function render( $attrs, $content = null, $render_slug ) {
        $open_icon = $this->props['open_icon'];
        $close_icon = $this->props['close_icon'];
		$img_sz = $this->props['image'];
		$title_space = $this->props['title_space'];
		$text_space = $this->props['text_space'];
		$title_size = $this->props['title_size'];
		$text_size = $this->props['text_size'];
		$footer_bg= $this->props['footer_bg'];
		$footer_text = $this->props['footer_text'];
		$footer_icon = $this->props['footer_icon'];

		$title_styles = "
			min-height:$title_size;
			margin-top:$title_space;
		";

		$text_styles = "
			min-height:$text_size;
			margin-top:$text_space;
		";


		$out = sprintf( '
            <div class="accordion-item">
                <div class="accordion-title">
                    <p class="title-content">%1$s</p>
                    <p class=".accordion-controls">
                        <span class="tog-item open-icon active" style="' . $img_sz . '">
                            <img src=' . $open_icon . ' alt="" />
                        </span>
                        <span class="tog-item close-icon" style="width:' . $img_sz . '">
                            <img src=' . $close_icon . ' alt="" />
                        </span>
                    </p>
                </div>
                <div class="accordion-body">
					<div class="body-title"  style="' . $title_styles . '">
						<div class="body-title-inner">
							%2$s
						</div>
					</div>
					<div class="body-text">
						<div class="body-text-inner"  style="min-height:' . $text_styles . '">
							%3$s
						</div>
					</div>
				</div>
            ',
            $this->props['category'],
			$this->props['title'],
            $this->props['content'],
			$footer_text,
			$footer_icon
        );


	if($footer_text){
		$out .= "
			<footer class='item-footer' style='background:$footer_bg' >
				<p class='footer-text'>$footer_text</p>
				<span class='footer-icon'>
					<img src=$footer_icon />
				</span>
			</footer>
		";
	}

	$out .= "</div>";


	return $out;

	}
}

new NEW_AccordionChild;
