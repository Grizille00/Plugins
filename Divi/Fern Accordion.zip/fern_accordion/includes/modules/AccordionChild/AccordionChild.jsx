// External Dependencies
import React, { Component } from 'react';

// Internal Dependencies
import './style.css';


class AccordionChild extends Component {

  static slug = 'new_fern_accordion_child';


  _renderProp(value, fieldName, fieldType, renderSlug) {
    const utils      = window.ET_Builder.API.Utils;
    const _          = utils._;
    const orderClass = `${this.props.moduleInfo.type}_${this.props.moduleInfo.order}`;

    let output = '';

    if (! value) {
      return output;
    }

    switch (fieldType) {
      case 'options_list':
        value = utils.decodeOptionListValue(value);

        if (_.isArray(value)) {
          output = value.map((option, index) => {
            return (
              <option key={`${orderClass}-${index}`} value={option.value}>{option.value}</option>
            );
          });
        }
        break;
      case 'options_list_checkbox':
        const checkboxName = `${orderClass}_${fieldName}`;

        value = utils.decodeOptionListValue(value);

        if (_.isArray(value)) {
          output = value.map((option, index) => {
            const checkboxID = `${checkboxName}_${index}`;
            const isChecked  = 1 === option.checked;

            return (
              <span className="checkbox-wrap" key={`${orderClass}-${index}`}>
                <input type="checkbox" id={checkboxID} className="input" value={option.value} readOnly={true} checked={isChecked}/>
                <label htmlFor={checkboxID}><i></i>{option.value}</label>
              </span>
            );
          });
        }
        break;
      case 'options_list_radio':
        const radioName = `${orderClass}_${fieldName}`;

        value = utils.decodeOptionListValue(value);

        if (_.isArray(value)) {
          output = value.map((option, index) => {
            const radioId   = `${radioName}_radio_${index}`;
            const isChecked = 1 === option.checked;

            return (
              <span key={`${orderClass}-${index}`} className="radio-wrap">
                <input type="radio" id={radioId} className="input" value={option.value} name={radioName} readOnly={true} checked={isChecked}/>
                <label htmlFor={radioId}><i></i>{option.value}</label>
              </span>
            );
          });
        }
        break;
      case 'font_icon':
        output = (
          <span className="et-pb-icon" style={{fontFamily: '"ETmodules"', fontSize: 30}}>{utils.processFontIcon(value)}</span>
        );
        break;
      case 'upload_image':
        output = <span className="et-pb-icon"><img src={value} alt=''/></span>;
        break;
      default:
        output = value;
        break;
    }

    return output;
  }

  static css(props) {
    const additionalCss = [];
    if (props.image){
      additionalCss.push([{
        selector:    '%%order_class%% .tog-item',
        declaration: `width: ${props.image};`,
      }]);
    }


    if (props.title_size){
        additionalCss.push([{
          selector:    '%%order_class%% .accordion-body .body-title',
          declaration: `min-height: ${props.title_size};`,
        }]);
      }

    if (props.text_size){
        additionalCss.push([{
          selector:    '%%order_class%% .accordion-body .body-text',
          declaration: `min-height: ${props.text_size};`,
        }]);
      }

    if (props.title_space){
        additionalCss.push([{
          selector:    '%%order_class%% .accordion-body .body-title',
          declaration: `margin-top: ${props.title_space};`,
        }]);
      }

    if (props.text_space){
        additionalCss.push([{
          selector:    '%%order_class%% .accordion-body .body-text',
          declaration: `margin-top: ${props.text_space};`,
        }]);
      }


      if (props.footer_bg){
        additionalCss.push([{
          selector:    '%%order_class%% .accordion-item .item-footer',
          declaration: `background: ${props.footer_bg};`,
        }]);
      }


    return additionalCss;
  }

  render() {

    return (
      <div className="accordion-item">
          <div className="accordion-title">
              <p className="title-content">{this.props.category}</p>
              <p className="accordion-controls">
                  <span className="tog-item open-icon active" >
                      <img src={this.props.open_icon} alt=""/>
                  </span>
                  <span className="tog-item close-icon">
                      <img src={this.props.close_icon} alt=""/>
                  </span>
              </p>
          </div>
          <div class="accordion-body">
              <div class="body-title">{this.props.title}</div>
              <div class="body-text">{this.props.content()}</div>
          </div>
          {this.props.footer_text?
          <footer class="item-footer">
					<p class="footer-text">{this.props.footer_text}</p>
					<span class="footer-icon">
            <img src={this.props.footer_icon}/>
          </span>
				</footer>
        :<></>
          }
        
      </div>
    );
  }
}

export default AccordionChild;
