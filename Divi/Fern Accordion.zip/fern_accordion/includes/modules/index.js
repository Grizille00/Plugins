import Accordion from './Accordion/Accordion';
import AccordionChild from './AccordionChild/AccordionChild';

export default [
    Accordion,
    AccordionChild
];
