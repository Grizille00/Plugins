// External Dependencies
import React, { Component } from 'react';

// Internal Dependencies
import './style.css';


class Accordion extends Component {

  static slug = 'new_fern_accordion';


  render() {

    return (
      <div className='accordion-wrapper'>{this.props.content}</div>
    );
  }
}

export default Accordion;
