<?php

class NEW_Accordion extends ET_Builder_Module {

	public $slug       = 'new_fern_accordion';
    public $child_slug = 'new_fern_accordion_child';
	public $vb_support = 'on';

	protected $module_credits = array(
		'module_uri' => 'https://bit.ly/fern-helper',
		'author'     => 'Michael Sithole',
		'author_uri' => 'michael.sithole@uncommon.org',
	);

	public function init() {
		$this->name = esc_html__( 'Fern Accordion', 'new-new' );
		$this->icon_path =  plugin_dir_path( __FILE__ ) . 'icon.svg';


	}




	public function render( $attrs, $content = null, $render_slug ) {
		return sprintf( '<div class="accordion-wrapper">%1$s</div>', $this->content );
	}
}

new NEW_Accordion;
