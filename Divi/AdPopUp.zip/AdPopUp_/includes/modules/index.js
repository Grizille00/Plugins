// import HelloWorld from './HelloWorld/HelloWorld';

import AdPopUp from "./AdPopUp/AdPopUp";

export default [AdPopUp];
