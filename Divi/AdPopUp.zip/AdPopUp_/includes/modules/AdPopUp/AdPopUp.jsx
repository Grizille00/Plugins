// External Dependencies
import React, { Component } from 'react';

// Internal Dependencies
import './style.css';


class AdPopUp extends Component {

  static slug = 'new_ad_pop_up';

  render() {
    // const Content = this.props.content;

    return (
      <div className="ad-ctl-wrapper">
        <p className='title'>{this.props.title}</p>
				<p className="item">{this.props.target}</p>
        <p className="close-btn">{this.props.close_button}</p>
			</div>
    );
  }
}

export default AdPopUp;
