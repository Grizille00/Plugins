<?php

class NEW_AdPopUp extends ET_Builder_Module {

	public $slug       = 'new_ad_pop_up';
	public $vb_support = 'on';

	protected $module_credits = array(
		'module_uri' => 'https://bit.ly/fern-helper',
		'author'     => 'Michael Sithole',
		'author_uri' => 'michael.sithole@uncommon.org',
	);

	public function init() {
		$this->name = esc_html__( 'Ad PopUp', 'new-new' );


		$this->icon_path =  plugin_dir_path( __FILE__ ) . 'icon.svg';

		$this->settings_modal_toggles  = array(
			'general'  => array(
				'toggles' => array(
					'main_content'	=> esc_html__( 'Ad Element', 'new-new' ),
					'settings'      => esc_html__( 'Ad Settings', 'new-new' ),
				),
			),
		);
	}

	public function get_fields() {
		return array(
			'title' => array(
				'label'           => esc_html__( 'Ad Title', 'new-new' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'Ad Title to ealisy track ad.', 'new-new' ),
				'toggle_slug'     => 'main_content',
			),
			'target' => array(
				'label'           => esc_html__( 'Ad Selector', 'new-new' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'Enter the Ad Selector here which will be used to identify your ad on your page.', 'new-new' ),
				'toggle_slug'     => 'main_content',
			),

			'close_button' => array(
				'label'           => esc_html__( 'Ad Close Controller Selector', 'new-new' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'The item with this selecor will be used to dismiss the ad.', 'new-new' ),
				'toggle_slug'     => 'main_content',
			),
			
		);
	}

	

	public function render( $attrs, $content = null, $render_slug ) {
		$logfile = __DIR__ . '/' . $this->props['title'] . '.txt' ;
		$ip = $_SERVER['REMOTE_ADDR'];
		$disp = false;
		function process_user($logfile,$ip){
			file_put_contents($logfile,"$ip|", FILE_APPEND);
		}

		function check_user($logfile,$ip){
			$present = false;
			$res = file_get_contents($logfile);
    		$data = explode('|',$res);
			foreach($data as $item){
				$present = $present || $ip == $item;
			}
			return $present;

		}
		if (!check_user($logfile,$ip)){
			process_user($logfile,$ip);
			$disp = true;
		} 

		// echo $disp;
		
		
		return sprintf( '
			<div class="ad-ctl-wrapper">
				<p class="title">%3$s</p>
				<p class="item">%1$s</p>
				<p class="close-btn">%4$s</p>
				<p class="show">%2$s</p>
			</div>
		', 
		$this->props['target'],
		$disp,
		$this->props['title'],
		$this->props['close_button'], 
	);
	}
}

new NEW_AdPopUp;
