// This script is loaded both on the frontend page and in the Visual Builder.
const get = (item,mode=0)=>{
    if (mode===0){
      return document.querySelector(item).textContent.trim()
    } else{
      return document.querySelector(item)
    }
  }


const push_styles = (ad)=>{
    const el = document.createElement('style')
    const styles = `
        ${ad}.ad_active{
            display:block !important;
            visibility:visible !important;
            opacity:1 !important;
        }
        ${ad}{
            visibility:hidden !important;
            opacity:0 !important;
            transition:450ms ease;
        }
    `
    el.textContent = styles
    get('body',1).appendChild(el)
}



const ad = get('.ad-ctl-wrapper')

if(ad){
    const ad_attrs = {
        title:get('.ad-ctl-wrapper .title'),
        ad:get('.ad-ctl-wrapper .item'),
        active:get('.ad-ctl-wrapper .show'),
        controller:get('.ad-ctl-wrapper .close-btn')
    }
    push_styles(ad_attrs.ad)

    if (ad_attrs.active == '1'){
        get(ad_attrs.ad,1).classList.add('ad_active')
        get(`${ad_attrs.ad} ${ad_attrs.controller}`,1).addEventListener('click',()=>{
            console.log('hi')
            get(ad_attrs.ad,1).classList.remove('ad_active')
        })

    }

    console.log(ad_attrs)


}

