import Slick from "./Slick/Slick";

export default [Slick];
