<?php

class NEW_Slick extends ET_Builder_Module {

	public $slug       = 'new_slick';
	public $vb_support = 'on';


	protected $module_credits = array(
		'module_uri' => 'https://bit.ly/fern-helper',
		'author'     => 'Michael Sithole',
		'author_uri' => 'michael.sithole@uncommon.org',
	);

	public function init() {
		$this->name = esc_html__( 'Slick Slider', 'new-new' );
		$this->icon_path =  plugin_dir_path( __FILE__ ) . 'icon.svg';

		$this->settings_modal_toggles  = array(
			'general'  => array(
				'toggles' => array(
					'main_content'	=> esc_html__( 'Slick Selector', 'new-new' ),
					'settings'      => esc_html__( 'Slick Settings', 'new-new' ),
					'controls'      => esc_html__( 'Slick Controls', 'new-new' ),
					'mode'        	=> esc_html__( 'Slick Mode', 'new-new' ),
				),
			),
		);
	}

	public function get_fields() {
		return array(
			'element' => array(
				'label'           => esc_html__( 'Slick Parent', 'new-new' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'The Css Selector Entered Here will be used as the Slick Parent Target.', 'new-new' ),
				'toggle_slug'     => 'main_content',
			),
			'slides_to_show' => array(
				'label'           => esc_html__( 'Slides To Show', 'new-new' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'This defines number of slides the slick slider displays at once.', 'new-new' ),
				'toggle_slug'     => 'settings',
				'mobile_options'  => true,
				'hover'           => 'tabs',
			),
			'slides_to_scroll' => array(
				'label'           => esc_html__( 'Slides To Scroll', 'new-new' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'This defines number of slides the slick slider scrolls at once.', 'new-new' ),
				'toggle_slug'     => 'settings',
				'mobile_options'  => true,
				'hover'           => 'tabs',
			),
			'center_padding' => array(
				'label'           => esc_html__( 'Center Padding', 'new-new' ),
				'type'            => 'range',
				'input_attrs' 		=> array(
					'min'  => 10,
					'max'  => 32,
					'step' => 1
				),
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'This defines center padding between slides  of the slick slider.', 'new-new' ),
				'toggle_slug'     => 'settings',
				'mobile_options'  => true,
				'hover'           => 'tabs',

			),
			'center_mode'         => array(
				'label'           => esc_html__( 'Center Mode', 'new-new' ),
				'type'            => 'yes_no_button',
				'option_category' => 'basic_option',
				'options'         => array(
					'on'  => esc_html__( 'Yes', 'new-new' ),
					'off' => esc_html__( 'No', 'new-new' ),
				),
				'default_on_front' => 'on',
				'toggle_slug'     => 'settings',
				'mobile_options'  => true,
				'hover'           => 'tabs',
				'description'     => esc_html__( 'This will enable/disable center mode on slick.', 'new-new' ),
			),
			'autoplay'         => array(
				'label'           => esc_html__( 'Autoplay Setting', 'new-new' ),
				'type'            => 'yes_no_button',
				'option_category' => 'basic_option',
				'options'         => array(
					'on'  => esc_html__( 'Yes', 'new-new' ),
					'off' => esc_html__( 'No', 'new-new' ),
				),
				'default_on_front' => 'on',
				'toggle_slug'     => 'settings',
				'mobile_options'  => true,
				'hover'           => 'tabs',
				'description'     => esc_html__( 'This will enable/disable autoplay mode on slick.', 'new-new' ),
			),
			'autoplay_speed' => array(
				'label'           => esc_html__( 'Autoplay Speed', 'new-new' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'mobile_options'  => true,
				'hover'           => 'tabs',
				'description'     => esc_html__( 'This defines milliseconds delay before slick switches.', 'new-new' ),
				'toggle_slug'     => 'settings',
			),


			'arrows'         => array(
				'label'           => esc_html__( 'Slick Arrows', 'new-new' ),
				'type'            => 'yes_no_button',
				'option_category' => 'basic_option',
				'options'         => array(
					'on'  => esc_html__( 'Yes', 'new-new' ),
					'off' => esc_html__( 'No', 'new-new' ),
				),
				'default_on_front' => 'on',
				'mobile_options'  => true,
				'hover'           => 'tabs',
				'toggle_slug'     => 'controls',
				'description'     => esc_html__( 'This will enable/disable arrows mode on slick.', 'new-new' ),
			),

			'dots'         => array(
				'label'           => esc_html__( 'Slick Dots', 'new-new' ),
				'type'            => 'yes_no_button',
				'option_category' => 'basic_option',
				'options'         => array(
					'on'  => esc_html__( 'Yes', 'new-new' ),
					'off' => esc_html__( 'No', 'new-new' ),
				),
				'default_on_front' => 'on',
				'toggle_slug'     => 'controls',
				'mobile_options'  => true,
				'hover'           => 'tabs',
				'description'     => esc_html__( 'This will enable/disable dots mode on slick.', 'new-new' ),
			),

			'infinite'         => array(
				'label'           => esc_html__( 'Infinite Scroll', 'new-new' ),
				'type'            => 'yes_no_button',
				'option_category' => 'basic_option',
				'options'         => array(
					'on'  => esc_html__( 'Yes', 'new-new' ),
					'off' => esc_html__( 'No', 'new-new' ),
				),
				'default_on_front' => 'on',
				'toggle_slug'     => 'controls',
				'description'     => esc_html__( 'This will enable/disable infinite scroll mode on slick.', 'new-new' ),
			),

			'next_arrow' => array(
				'label'           => esc_html__( 'Slick Next Arrow Selector', 'new-new' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'This defines slick next arrow selector', 'new-new' ),
				'toggle_slug'     => 'controls',
			),

			'prev_arrow' => array(
				'label'           => esc_html__( 'Slick Prev Arrow Selector', 'new-new' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'This defines slick prev arrow selector', 'new-new' ),
				'toggle_slug'     => 'controls',
			),

			'slick_mode'         => array(
				'label'           => esc_html__( 'Slick Mode', 'new-new' ),
				'type'            => 'select',
				'option_category' => 'basic_option',
				'options'         => array(
					'horizontal'  => esc_html__( 'Horizontal', 'new-new' ),
					'vertical' 	=> esc_html__( 'Vertical', 'new-new' ),
					'fade'		=> esc_html__( 'Fade', 'new-new' ),
				),
				'default_on_front' => 'on',
				'mobile_options'  => true,
				'hover'           => 'tabs',
				'toggle_slug'     => 'mode',
				'description'     => esc_html__( 'This will determine the  mode of the slick.', 'new-new' ),
			),
		);
	}


	

	public function render( $attrs, $content = null, $render_slug ) {
		
		function runner($items){
			$res = '';
			foreach($items as $item){
				$res .= $item . ":";
			}
			return $res;
		}


		$multi_view = et_pb_multi_view_options( $this );
		$slides_to_show = runner($multi_view->get_values('slides_to_show'));
		$slides_to_scroll = runner($multi_view->get_values('slides_to_scroll'));
		$center_padding = runner($multi_view->get_values('center_padding'));
		$center_mode = runner($multi_view->get_values('center_mode'));
		$autoplay = runner($multi_view->get_values('autoplay'));
		$autoplay_speed = runner($multi_view->get_values('autoplay_speed'));
		$arrows = runner($multi_view->get_values('arrows'));
		$dots = runner($multi_view->get_values('dots'));
		$slick_mode = runner($multi_view->get_values('slick_mode'));
		





		return sprintf( '
			<div class="slick-settings-wrapper" style="display:none">
				<p class="parent">%1$s</p>
				<p class="slides_to_show">%2$s</p>
				<p class="slides_to_scroll">%3$s</p>
				<p class="center_padding">%4$s</p>
				<p class="center_mode">%5$s</p>
				<p class="autoplay">%6$s</p>
				<p class="autoplay_speed">%7$s</p>
				<p class="arrows">%8$s</p>
				<p class="dots">%9$s</p>
				<p class="infinite">%10$s</p>
				<p class="next_arrow">%11$s</p>
				<p class="prev_arrow">%12$s</p>
				<p class="slick_mode">%13$s</p>
			</div>
        ',$this->props['element'],
		$slides_to_show,
		$slides_to_scroll,
		$center_padding,
		$center_mode,
		$autoplay,
		$autoplay_speed,
		$arrows,
		$dots,
		$this->props['infinite'],
		$this->props['next_arrow'],
		$this->props['prev_arrow'],
		$slick_mode
		

    );
	}
}

new NEW_Slick;
