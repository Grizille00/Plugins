// External Dependencies
import React, { Component } from 'react';

// Internal Dependencies
import './slick_src/slick-theme.css'
import './slick_src/slick.css'
import './slick_src/fonts/slick.ttf'
import './style.css';


class Slick extends Component {

  static slug = 'new_slick';

  render() {
    // const Content = this.props.content;

    return (
      <div className="slick-settings-wrapper" style={{display:'none'}}>
				<p className="parent">{this.props.element}</p>
				<p className="slides_to_show">{this.props.slides_to_show}</p>
        <p className="slides_to_scroll">{this.props.slides_to_scroll}</p>
        <p className="center_padding">{this.props.center_padding}</p>
        <p className="center_mode">{this.props.center_mode}</p>
        <p className="autoplay">{this.props.autoplay}</p>
        <p className="autoplay_speed">{this.props.autoplay_speed}</p>
        <p className="arrows">{this.props.arrows}</p>
        <p className="dots">{this.props.dots}</p>
        <p className="infinite">{this.props.infinite}</p>
        <p className="next_arrow">{this.props.next_arrow}</p>
        <p className="prev_arrow">{this.props.prev_arrow}</p>
        <p className="slick_mode">{this.props.slick_mode}</p>
			</div>
    );
  }
}

export default Slick;
