import '../includes/modules/Slick/slick_src/slick'
// This script is loaded both on the frontend page and in the Visual Builder.

const get = (item,mode=0)=>{
  if (mode===0){
    return document.querySelector(item)
  } else{
    return document.querySelectorAll(item)
  }
}

const get_child = (item,child)=>{
  const res = item.getElementsByClassName(child)[0]
  return res.textContent.trim()
}





const splitter = (txt,mode=0)=>{
  const bb =  txt.split(':')
  const res = []

  for (let i = 0; i < 3; i++) {
    const item = bb[i]
    if(item){
      if(mode==1){
        res.push(Number(item.trim()))
      } else{
        res.push(item.trim())
      }

     
    }
  }
  return res
}


const el = get('.slick-settings-wrapper')




if (el){
  // console.log(el)
  const slick_modes = {
    vertical:[false,false,false],
    horizontal:[false,false,false],
    fade:[false,false,false]
  }
  const slick_attrs = {
    par:get_child(el,'parent'),
    slides_to_show:splitter(get_child(el,'slides_to_show')),
    slides_to_scroll:splitter(get_child(el,'slides_to_scroll')),
    center_padding:splitter(get_child(el,'center_padding').replaceAll('px','').trim()),
    autoplay_speed:splitter(get_child(el,'autoplay_speed'),1),
    infinite:get_child(el,'infinite')=='on'?true:false,
    next_arrow:get_child(el,'next_arrow'),
    prev_arrow:get_child(el,'prev_arrow'),
    mode:splitter(get_child(el,'slick_mode')),
    
  }
  let items = ['center_mode','autoplay','arrows','dots']

  for (let x = 0; x < items.length; x++) {
    const out = []
    const res = splitter(get_child(el,'center_mode'))
    for (let y = 0; y < res.length; y++) {
      out.push(res[y]=='on'?true:false)
    }
    slick_attrs[items[x]] = out

  }
  for (let i = 0; i < slick_attrs.mode.length; i++) {
    slick_modes[slick_attrs.mode[i]] = true
    
  }
  

  jQuery(function($) {

    $(slick_attrs.par).slick({
      centerMode: slick_attrs.center_mode[0],
      centerPadding: `${slick_attrs.center_padding[0]}px`,
      slidesToShow: slick_attrs.slides_to_show[0],
      slidesToScroll:slick_attrs.slides_to_scroll[0],
      autoplay:slick_attrs.autoplay[0],
      autoplaySpeed:slick_attrs.autoplay_speed[0],
      arrows:slick_attrs.arrows[0],
      dots:slick_attrs.dots[0],
      infinite: slick_attrs.infinite,
      nextArrow:slick_attrs.next_arrow,
      prevArrow:slick_attrs.prev_arrow,
      vertical:slick_modes.vertical[0],
      horizontal:slick_modes.horizontal[0],
      fade:slick_modes.fade[0],
      responsive: [
        {
          breakpoint: 992,
          settings: {
            slidesToShow: slick_attrs.slides_to_show[1],
            centerMode: slick_attrs.center_mode[1],
            centerPadding: `${slick_attrs.center_padding[1]}px`,
            slidesToScroll:slick_attrs.slides_to_scroll[1],
            autoplay:slick_attrs.autoplay[1],
            autoplaySpeed:slick_attrs.autoplay_speed[1],
            arrows:slick_attrs.arrows[1],
            dots:slick_attrs.dots[1],
            vertical:slick_modes.vertical[1],
            horizontal:slick_modes.horizontal[1],
            fade:slick_modes.fade[1],
          }
        },
        
        {
          breakpoint: 576,
          settings: {
            slidesToShow: slick_attrs.slides_to_show[2],
            centerMode: slick_attrs.center_mode[2],
            centerPadding: `${slick_attrs.center_padding[2]}px`,
            slidesToScroll:slick_attrs.slides_to_scroll[2],
            autoplay:slick_attrs.autoplay[2],
            autoplaySpeed:slick_attrs.autoplay_speed[2],
            arrows:slick_attrs.arrows[2],
            dots:slick_attrs.dots[2],
            vertical:slick_modes.vertical[2],
            horizontal:slick_modes.horizontal[2],
            fade:slick_modes.fade[2],
          }
        }

      ]
      });
  
  });
  

}

